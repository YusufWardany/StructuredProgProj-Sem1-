import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import  java.util.Map;
import java.util.ArrayList;
import java.util.List;
public class events {

    private List<String>attendees;
    private String title;
    private Date StartTime;
    private Date endTime;
    private String location;
    private String description;




    public events(String title,Date startTime,Date endTime,
                  String location,String description) {
        this.title=title;
        this.StartTime=startTime;
        this.endTime=endTime;
        this.location=location;
        this.description=description;

        attendees=new ArrayList<>();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getStartTime() {
        return StartTime;
    }

    public void setStartTime(Date startTime) {
        StartTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



  public void addAttendee(String attendee){
        attendees.add(attendee);
  }
  public void removeAttendee(String attendee){
        attendees.remove(attendee);
  }
public boolean isAllDayEvent(){
        return isAllDayEvent();
}
public boolean isRecurringEvent(){
        return isAllDayEvent();
}
public void setRecurringEvent(String recurringEvent){

}
public String getRecurringPattern(){
        return getRecurringPattern();
}
public void setRecurringPattern(String recurringPattern){

}

    @Override
    public String toString() {
        return "events{" +
                "attendees=" + attendees +
                ", title='" + title + '\'' +
                ", StartTime=" + StartTime +
                ", endTime=" + endTime +
                ", location='" + location + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}

