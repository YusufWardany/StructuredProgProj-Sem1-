public class professors extends person{
    private String material;

    public professors(String password, String name, String email, String material) {
        super(password, name, email);
        this.material=material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return "professors{" +
                "material='" + material + '\'' +
                '}';
    }
}
