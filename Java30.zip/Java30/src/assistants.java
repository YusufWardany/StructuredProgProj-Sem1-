public class assistants extends person{
private String labs;

    public assistants(String password, String name, String email,String labs) {

        super(password, name, email);
        this.labs=labs;
    }

    public String getLabs() {
        return labs;
    }

    public void setLabs(String labs) {
        this.labs = labs;
    }

    @Override
    public String toString() {
        return "assistants{" +
                "labs='" + labs + '\'' +
                '}';
    }
}
