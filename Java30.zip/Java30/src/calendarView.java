import java.time.LocalDate;

public class calendarView {
    private int year;
    private int month;

    public calendarView(int year,int month) {
      this.year=year;
        this.month = month;
    }
    public void displayCalendar(){
        LocalDate date=LocalDate.of(year,month,1);
        System.out.println(date.getMonth()+" "+date.getYear());   //print month and year
        System.out.println("     sun   mon   tue   wed   thu   fri   sat");

        int offSet=date.getDayOfWeek().getValue()%7;          //calculate the offSet for the first day of month

        for(int i=0;i<offSet;i++){
            System.out.print("");  //print the empty cells before the first day
        }

        int daysInMonth=date.lengthOfMonth();
        for (int day=1;day<=daysInMonth;day++){
            System.out.printf("%6d",day);           //print the days of month
            date=date.plusDays(1);
            if(date.getDayOfWeek().getValue()%7==0){
                System.out.println();
            }
        }
        System.out.println();
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    @Override
    public String toString() {
        return "calendarView{" +
                "year=" + year +
                ", month=" + month +
                '}';
    }
}
