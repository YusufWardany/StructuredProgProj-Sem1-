public class Monthly extends calendarView {


    public Monthly(int year, int month) {
        super(year, month);

    }

    public void display(){
        System.out.println("Displaying monthly view for"+" "+getYear()+" "+getMonth());
    }
}
