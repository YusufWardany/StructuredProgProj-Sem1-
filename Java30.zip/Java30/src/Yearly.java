public class Yearly extends calendarView{



    public Yearly(int year, int month) {
        super(year, month);

    }

   public void display(){
       System.out.println("Displaying yearly view for"+" "+getYear());
   }
}
