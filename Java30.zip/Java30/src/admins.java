public class admins extends person{
    private String Groups;

    public admins(String password, String name, String email, String groups) {
        super(password, name, email);
        Groups = groups;
    }

    public String getGroups() {
        return Groups;
    }

    public void setGroups(String groups) {
        Groups = groups;
    }

    @Override
    public String toString() {
        return "admins{" +
                "Groups='" + Groups + '\'' +
                '}';
    }
}
