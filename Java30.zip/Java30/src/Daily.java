import java.time.LocalDate;

public class Daily extends calendarView{
    private LocalDate date;

    public Daily(int year, int month, LocalDate date) {
        super(year, month);
        this.date = date;
    }

    public void display(){
        System.out.println("Displaying daily view for"+" "+date);
    }
}
