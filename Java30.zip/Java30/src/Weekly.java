import java.time.LocalDate;

public class Weekly extends calendarView {
    private LocalDate startDate;

    public Weekly(int year, int month, LocalDate startDate) {
        super(year, month);
        this.startDate = startDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public void display(){
        System.out.println("Displaying weekly view starting from"+" "+startDate);
    }
}
