public class instructors extends person {
private String activities;

    public instructors(String password, String name, String email,String activities) {
        super(password, name, email);
        this.activities=activities;
    }

    public String getActivities() {
        return activities;
    }

    public void setActivities(String activities) {
        this.activities = activities;
    }

    @Override
    public String toString() {
        return "instructors{" +
                "activities='" + activities + '\'' +
                '}';
    }
}