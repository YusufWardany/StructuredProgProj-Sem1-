public class Students extends person{
    private String assignments;
    private String exams;

    private String courses;

    public Students(String password, String name, String email, String assignments,String exams
    ,String courses) {
        super(password, name, email);
        this.assignments = assignments;
        this.exams=exams;
        this.courses=courses;
    }

    public String getCourses() {
        return courses;
    }

    public void setCourses(String courses) {
        this.courses = courses;
    }

    public String getAssignments() {
        return assignments;
    }

    public void setAssignments(String assignments) {
        this.assignments = assignments;
    }

    public String getExams() {
        return exams;
    }

    public void setExams(String exams) {
        this.exams = exams;
    }

    @Override
    public String toString() {
        return "Students{" +
                "assignments='" + assignments + '\'' +
                ", exams='" + exams + '\'' +
                ", courses='" + courses + '\'' +
                '}';
    }
}
