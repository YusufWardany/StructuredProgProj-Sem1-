public abstract class AbstractClass {
    public abstract void display();     //display the calendar
    public abstract void addEvent(String eventName,String date);  //Add an event to the calendar
    public abstract void removeDate(String eventName);            //remove an event from the calendar
    public abstract void ListEvents();                            //list all events in the calendar
    public void greetUser(){
        System.out.println("Welcome to the digital calendar . . . ");
    }

}
