import java.time.LocalDate;
import java.util.Date;

public class Main {
    public static void main(String[] args) {

      events event1=new events("Final exam",new Date(4/8),
              new Date(26/8),"university","exam");

        System.out.println(event1.toString());

        calendarView view=new calendarView(2023,8);
        view.displayCalendar();

    /*    Yearly yearly=new Yearly(2023,8);
        yearly.display();
        Monthly monthly=new Monthly(2023,8);
        monthly.display();
        Weekly weekly=new Weekly(2023,8,14);
        weekly.display();
        Daily daily=new Daily(2023,8,15);
        daily.display();;  */


        events events=new events("meeting",new Date(),new Date(),"uni","Tutorial");
        System.out.println(event1.toString());



    }
    }
